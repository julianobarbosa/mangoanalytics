
https://pypi.python.org/pypi/wsgilog/
