Similar projects
----------------
    * django-odeon http://od-eon.com/labs/django-cherrypy-odeon/
    * django-cpserver
    * django cherrypy management command 
