========================================
django-wsgiserver testproject for django
========================================
This is now being tested with django 1.5

This project skeleton is from Two scoops of django by Roy and Greenfield (see their license)

See the README for django-wsgiserver for how to use this to test

    $ pip install -r requirements.txt

*note: We install production requirements this way because many Platforms as a
Services expect a requirements.txt file in the root of projects.*

Acknowledgements
================

    - Many thanks to Randall Degges for the inspiration to write the book and django-skel.
    - All of the contributors_ to this project.

.. _contributors: https://github.com/twoscoops/django-twoscoops-project/blob/master/CONTRIBUTORS.txt
