from settings import *

DEBUG = TEMPLATE_DEBUG = False